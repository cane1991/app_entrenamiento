// Configuración de base de datos con Supabase
import { createClient } from "@supabase/supabase-js"

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

export const supabase = createClient(supabaseUrl, supabaseKey)

// Tipos de datos
export interface User {
  id: string
  email: string
  name: string
  created_at: string
}

export interface Exercise {
  id: string
  name: string
  description: string
  video_url: string
  muscle_groups: string[]
  difficulty: "Principiante" | "Intermedio" | "Avanzado"
}

export interface UserRoutine {
  id: string
  user_id: string
  name: string
  description: string
  trainer: string
  current_week: number
  total_weeks: number
  exercises: Exercise[]
}

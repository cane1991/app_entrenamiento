"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Play, Calendar, Users, TrendingUp, Clock, LogOut } from "lucide-react"
import ExerciseLibrary from "./components/exercise-library"
import TrainingPlanner from "./components/training-planner"
import MyRoutine from "./components/my-routine"
import LoginForm from "./components/login-form"

// Simulación de usuarios para demo
const mockUsers = [
  {
    id: 1,
    email: "juan@email.com",
    password: "123456",
    name: "Juan Pérez",
    assignedPlan: "Plan de Fuerza - 4 semanas",
  },
  {
    id: 2,
    email: "maria@email.com",
    password: "123456",
    name: "María González",
    assignedPlan: "Cardio HIIT - 6 semanas",
  },
  {
    id: 3,
    email: "carlos@email.com",
    password: "123456",
    name: "Carlos Ruiz",
    assignedPlan: "Principiantes - 8 semanas",
  },
]

export default function FitnessApp() {
  const [activeTab, setActiveTab] = useState("dashboard")
  const [user, setUser] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)

  // Verificar si hay una sesión guardada al cargar la página
  useEffect(() => {
    const savedUser = localStorage.getItem("currentUser")
    if (savedUser) {
      setUser(JSON.parse(savedUser))
    }
    setIsLoading(false)
  }, [])

  const handleLogin = (email: string, password: string) => {
    // Buscar usuario en la base de datos simulada
    const foundUser = mockUsers.find((u) => u.email === email && u.password === password)

    if (foundUser) {
      setUser(foundUser)
      localStorage.setItem("currentUser", JSON.stringify(foundUser))
      setActiveTab("my-routine") // Cambiar automáticamente a Mi Rutina después del login
      return { success: true }
    } else {
      return { success: false, error: "Email o contraseña incorrectos" }
    }
  }

  const handleLogout = () => {
    setUser(null)
    localStorage.removeItem("currentUser")
    setActiveTab("dashboard")
  }

  const stats = [
    { title: "Entrenamientos Activos", value: "12", icon: Calendar, color: "text-blue-600" },
    { title: "Ejercicios Disponibles", value: "156", icon: Play, color: "text-green-600" },
    { title: "Usuarios Registrados", value: "48", icon: Users, color: "text-purple-600" },
  ]

  const recentWorkouts = [
    {
      id: 1,
      name: "Entrenamiento de Fuerza - Tren Superior",
      date: "2024-01-15",
      duration: "45 min",
      status: "Completado",
    },
    { id: 2, name: "Cardio HIIT", date: "2024-01-14", duration: "30 min", status: "En Progreso" },
    { id: 3, name: "Entrenamiento de Piernas", date: "2024-01-13", duration: "60 min", status: "Completado" },
  ]

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Cargando...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-4">
              <div className="bg-blue-600 text-white p-2 rounded-lg">
                <TrendingUp className="h-6 w-6" />
              </div>
              <h1 className="text-2xl font-bold text-gray-900">FitnessPro</h1>
            </div>
            <div className="flex items-center space-x-4">
              <nav className="flex space-x-4">
                <Button
                  variant={activeTab === "dashboard" ? "default" : "ghost"}
                  onClick={() => setActiveTab("dashboard")}
                >
                  Dashboard
                </Button>
                <Button
                  variant={activeTab === "exercises" ? "default" : "ghost"}
                  onClick={() => setActiveTab("exercises")}
                >
                  Ejercicios
                </Button>
                <Button variant={activeTab === "planner" ? "default" : "ghost"} onClick={() => setActiveTab("planner")}>
                  Planificador
                </Button>
                <Button
                  variant={activeTab === "my-routine" ? "default" : "ghost"}
                  onClick={() => {
                    if (user) {
                      setActiveTab("my-routine")
                    } else {
                      setActiveTab("login")
                    }
                  }}
                >
                  Mi Rutina
                </Button>
              </nav>
              {user && (
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-gray-600">Hola, {user.name}</span>
                  <Button variant="outline" size="sm" onClick={handleLogout}>
                    <LogOut className="h-4 w-4 mr-1" />
                    Salir
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === "dashboard" && (
          <div className="space-y-8">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-2">Dashboard</h2>
              <p className="text-gray-600">Gestiona tus planes de entrenamiento y monitorea el progreso</p>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {stats.map((stat, index) => (
                <Card key={index}>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                        <p className="text-3xl font-bold text-gray-900">{stat.value}</p>
                      </div>
                      <stat.icon className={`h-8 w-8 ${stat.color}`} />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Recent Workouts */}
            <Card>
              <CardHeader>
                <CardTitle>Entrenamientos Recientes</CardTitle>
                <CardDescription>Últimas sesiones de entrenamiento</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentWorkouts.map((workout) => (
                    <div key={workout.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div className="bg-blue-100 p-2 rounded-lg">
                          <Play className="h-5 w-5 text-blue-600" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">{workout.name}</h3>
                          <div className="flex items-center space-x-2 text-sm text-gray-600">
                            <Calendar className="h-4 w-4" />
                            <span>{workout.date}</span>
                            <Clock className="h-4 w-4 ml-2" />
                            <span>{workout.duration}</span>
                          </div>
                        </div>
                      </div>
                      <Badge variant={workout.status === "Completado" ? "default" : "secondary"}>
                        {workout.status}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Login Prompt for My Routine */}
            {!user && (
              <Card className="border-blue-200 bg-blue-50">
                <CardContent className="p-6">
                  <div className="text-center">
                    <h3 className="text-lg font-semibold text-blue-900 mb-2">¿Quieres ver tu rutina personalizada?</h3>
                    <p className="text-blue-700 mb-4">
                      Inicia sesión para acceder a tu plan de entrenamiento personalizado
                    </p>
                    <Button onClick={() => setActiveTab("login")} className="bg-blue-600 hover:bg-blue-700">
                      Iniciar Sesión
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        )}

        {activeTab === "exercises" && <ExerciseLibrary />}
        {activeTab === "planner" && <TrainingPlanner />}
        {activeTab === "login" && <LoginForm onLogin={handleLogin} />}
        {activeTab === "my-routine" && user && <MyRoutine user={user} />}
        {activeTab === "my-routine" && !user && <LoginForm onLogin={handleLogin} />}
      </main>
    </div>
  )
}

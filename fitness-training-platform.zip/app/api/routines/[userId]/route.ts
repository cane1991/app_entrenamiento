import { type NextRequest, NextResponse } from "next/server"
import { supabase } from "@/lib/database"

export async function GET(request: NextRequest, { params }: { params: { userId: string } }) {
  try {
    // Obtener rutina del usuario
    const { data: routine, error } = await supabase
      .from("user_routines")
      .select(`
        *,
        routine_exercises (
          *,
          exercises (*)
        )
      `)
      .eq("user_id", params.userId)
      .single()

    if (error) {
      return NextResponse.json({ error: "Rutina no encontrada" }, { status: 404 })
    }

    return NextResponse.json(routine)
  } catch (error) {
    return NextResponse.json({ error: "Error interno del servidor" }, { status: 500 })
  }
}

"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Play, CheckCircle, Clock, Target, TrendingUp, Calendar, User } from "lucide-react"

interface MyRoutineProps {
  user: {
    id: number
    name: string
    email: string
    assignedPlan: string
  }
}

// Datos simulados de rutinas por usuario
const userRoutines: { [key: number]: any } = {
  1: {
    // Juan Pérez
    name: "Plan de Fuerza - 4 semanas",
    description: "Programa personalizado enfocado en el desarrollo de fuerza muscular",
    trainer: "Carlos Martínez",
    currentWeek: 2,
    totalWeeks: 4,
    completedSessions: 8,
    totalSessions: 12,
    exercises: [
      {
        id: 1,
        name: "Sentadillas",
        sets: "4 series x 12 reps",
        weight: "60kg",
        restTime: "90 seg",
        videoUrl: "/placeholder.svg?height=200&width=300",
        completed: true,
        lastCompleted: "2024-01-15",
      },
      {
        id: 2,
        name: "Press de Banca",
        sets: "4 series x 10 reps",
        weight: "70kg",
        restTime: "2 min",
        videoUrl: "/placeholder.svg?height=200&width=300",
        completed: true,
        lastCompleted: "2024-01-15",
      },
      {
        id: 3,
        name: "Peso Muerto",
        sets: "3 series x 8 reps",
        weight: "80kg",
        restTime: "3 min",
        videoUrl: "/placeholder.svg?height=200&width=300",
        completed: false,
        lastCompleted: null,
      },
      {
        id: 4,
        name: "Dominadas",
        sets: "3 series x 6 reps",
        weight: "Peso corporal",
        restTime: "2 min",
        videoUrl: "/placeholder.svg?height=200&width=300",
        completed: true,
        lastCompleted: "2024-01-14",
      },
    ],
  },
  2: {
    // María González
    name: "Cardio HIIT - 6 semanas",
    description: "Entrenamiento de alta intensidad para quemar grasa y mejorar resistencia",
    trainer: "Ana López",
    currentWeek: 3,
    totalWeeks: 6,
    completedSessions: 12,
    totalSessions: 18,
    exercises: [
      {
        id: 1,
        name: "Burpees",
        sets: "4 series x 15 reps",
        weight: "Peso corporal",
        restTime: "45 seg",
        videoUrl: "/placeholder.svg?height=200&width=300",
        completed: true,
        lastCompleted: "2024-01-15",
      },
      {
        id: 2,
        name: "Mountain Climbers",
        sets: "4 series x 30 seg",
        weight: "Peso corporal",
        restTime: "30 seg",
        videoUrl: "/placeholder.svg?height=200&width=300",
        completed: true,
        lastCompleted: "2024-01-15",
      },
      {
        id: 3,
        name: "Jump Squats",
        sets: "3 series x 20 reps",
        weight: "Peso corporal",
        restTime: "60 seg",
        videoUrl: "/placeholder.svg?height=200&width=300",
        completed: false,
        lastCompleted: null,
      },
      {
        id: 4,
        name: "High Knees",
        sets: "3 series x 45 seg",
        weight: "Peso corporal",
        restTime: "30 seg",
        videoUrl: "/placeholder.svg?height=200&width=300",
        completed: false,
        lastCompleted: null,
      },
    ],
  },
  3: {
    // Carlos Ruiz
    name: "Principiantes - 8 semanas",
    description: "Programa de introducción al fitness para desarrollar base física",
    trainer: "Luis García",
    currentWeek: 1,
    totalWeeks: 8,
    completedSessions: 3,
    totalSessions: 24,
    exercises: [
      {
        id: 1,
        name: "Flexiones de Pecho",
        sets: "3 series x 8 reps",
        weight: "Peso corporal",
        restTime: "60 seg",
        videoUrl: "/placeholder.svg?height=200&width=300",
        completed: true,
        lastCompleted: "2024-01-14",
      },
      {
        id: 2,
        name: "Sentadillas Básicas",
        sets: "3 series x 15 reps",
        weight: "Peso corporal",
        restTime: "45 seg",
        videoUrl: "/placeholder.svg?height=200&width=300",
        completed: true,
        lastCompleted: "2024-01-14",
      },
      {
        id: 3,
        name: "Plancha",
        sets: "3 series x 30 seg",
        weight: "Peso corporal",
        restTime: "60 seg",
        videoUrl: "/placeholder.svg?height=200&width=300",
        completed: false,
        lastCompleted: null,
      },
      {
        id: 4,
        name: "Caminata Rápida",
        sets: "1 serie x 20 min",
        weight: "N/A",
        restTime: "N/A",
        videoUrl: "/placeholder.svg?height=200&width=300",
        completed: false,
        lastCompleted: null,
      },
    ],
  },
}

export default function MyRoutine({ user }: MyRoutineProps) {
  const [completedExercises, setCompletedExercises] = useState<number[]>([])

  const userRoutine = userRoutines[user.id]

  if (!userRoutine) {
    return (
      <div className="space-y-6">
        <Card>
          <CardContent className="p-12 text-center">
            <User className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No tienes rutina asignada</h3>
            <p className="text-gray-600">Contacta a tu entrenador para que te asigne un plan personalizado</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  const completedCount = userRoutine.exercises.filter((ex: any) => ex.completed).length + completedExercises.length
  const totalExercises = userRoutine.exercises.length
  const progressPercentage = (completedCount / totalExercises) * 100

  const handleCompleteExercise = (exerciseId: number) => {
    if (!completedExercises.includes(exerciseId)) {
      setCompletedExercises([...completedExercises, exerciseId])
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold text-gray-900 mb-2">Mi Rutina de Entrenamiento</h2>
        <p className="text-gray-600">Bienvenido {user.name}, aquí está tu plan personalizado</p>
      </div>

      {/* Progress Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Progreso General</p>
                <p className="text-3xl font-bold text-gray-900">{Math.round(progressPercentage)}%</p>
              </div>
              <TrendingUp className="h-8 w-8 text-green-600" />
            </div>
            <Progress value={progressPercentage} className="mt-4" />
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Semana Actual</p>
                <p className="text-3xl font-bold text-gray-900">
                  {userRoutine.currentWeek}/{userRoutine.totalWeeks}
                </p>
              </div>
              <Calendar className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Ejercicios Completados</p>
                <p className="text-3xl font-bold text-gray-900">
                  {completedCount}/{totalExercises}
                </p>
              </div>
              <CheckCircle className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Routine Info */}
      <Card>
        <CardHeader>
          <CardTitle>{userRoutine.name}</CardTitle>
          <CardDescription>
            Entrenador: {userRoutine.trainer} • {userRoutine.description}
          </CardDescription>
        </CardHeader>
      </Card>

      {/* Exercises List */}
      <div className="space-y-4">
        <h3 className="text-xl font-semibold text-gray-900">Ejercicios de esta semana</h3>

        {userRoutine.exercises.map((exercise: any) => {
          const isCompleted = exercise.completed || completedExercises.includes(exercise.id)

          return (
            <Card key={exercise.id} className={`${isCompleted ? "border-green-200 bg-green-50" : ""}`}>
              <CardContent className="p-6">
                <div className="flex flex-col lg:flex-row gap-6">
                  {/* Exercise Video/Image */}
                  <div className="lg:w-1/3">
                    <div className="relative">
                      <img
                        src={exercise.videoUrl || "/placeholder.svg"}
                        alt={exercise.name}
                        className="w-full h-48 object-cover rounded-lg"
                      />
                      <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity rounded-lg">
                        <Button size="lg" className="bg-white text-black hover:bg-gray-100">
                          <Play className="h-5 w-5 mr-2" />
                          Ver Video
                        </Button>
                      </div>
                      {isCompleted && (
                        <div className="absolute top-2 right-2 bg-green-500 text-white p-1 rounded-full">
                          <CheckCircle className="h-5 w-5" />
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Exercise Details */}
                  <div className="lg:w-2/3 space-y-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="text-xl font-semibold text-gray-900">{exercise.name}</h4>
                        <div className="flex items-center space-x-4 text-sm text-gray-600 mt-2">
                          <div className="flex items-center">
                            <Target className="h-4 w-4 mr-1" />
                            <span>{exercise.sets}</span>
                          </div>
                          <div className="flex items-center">
                            <span className="font-medium">Peso: {exercise.weight}</span>
                          </div>
                          {exercise.restTime !== "N/A" && (
                            <div className="flex items-center">
                              <Clock className="h-4 w-4 mr-1" />
                              <span>Descanso: {exercise.restTime}</span>
                            </div>
                          )}
                        </div>
                      </div>
                      <Badge variant={isCompleted ? "default" : "secondary"}>
                        {isCompleted ? "Completado" : "Pendiente"}
                      </Badge>
                    </div>

                    {/* Last Completed Info */}
                    {exercise.lastCompleted && (
                      <div className="text-sm text-gray-600">
                        <span className="font-medium">Última vez completado:</span> {exercise.lastCompleted}
                      </div>
                    )}

                    {/* Action Button */}
                    <div className="pt-4">
                      {!isCompleted ? (
                        <Button className="w-full md:w-auto" onClick={() => handleCompleteExercise(exercise.id)}>
                          <CheckCircle className="h-4 w-4 mr-2" />
                          Marcar como Completado
                        </Button>
                      ) : (
                        <div className="flex items-center text-green-600">
                          <CheckCircle className="h-5 w-5 mr-2" />
                          <span className="font-medium">¡Ejercicio completado!</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Weekly Schedule Preview */}
      <Card>
        <CardHeader>
          <CardTitle>Planificación Semanal</CardTitle>
          <CardDescription>Tu horario de entrenamientos para esta semana</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-7 gap-2">
            {["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"].map((day, index) => (
              <div key={day} className="text-center">
                <div className="font-semibold text-sm text-gray-700 mb-2">{day}</div>
                <div className="space-y-1">
                  {index < 3 && (
                    <div className="bg-blue-100 text-blue-800 text-xs p-2 rounded">
                      {userRoutine.name.includes("Fuerza")
                        ? "Fuerza"
                        : userRoutine.name.includes("Cardio")
                          ? "Cardio"
                          : "Entrenamiento"}
                    </div>
                  )}
                  {index === 4 && (
                    <div className="bg-green-100 text-green-800 text-xs p-2 rounded">
                      {userRoutine.name.includes("Cardio") ? "HIIT" : "Complementario"}
                    </div>
                  )}
                  {(index === 5 || index === 6) && (
                    <div className="bg-gray-100 text-gray-600 text-xs p-2 rounded">Descanso</div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Calendar, Plus, Edit, Trash2, Clock, Target, Users } from "lucide-react"

const trainingPlans = [
  {
    id: 1,
    name: "Plan de Fuerza - 4 semanas",
    description: "Programa enfocado en el desarrollo de fuerza muscular",
    duration: "4 semanas",
    level: "Intermedio",
    sessions: 12,
    assignedUsers: 8,
    exercises: ["Sentadillas", "Peso Muerto", "Press Banca", "Dominadas"],
  },
  {
    id: 2,
    name: "Cardio HIIT - 6 semanas",
    description: "Entrenamiento de alta intensidad para quemar grasa",
    duration: "6 semanas",
    level: "Avanzado",
    sessions: 18,
    assignedUsers: 12,
    exercises: ["Burpees", "Mountain Climbers", "Jump Squats", "Sprint"],
  },
  {
    id: 3,
    name: "Principiantes - 8 semanas",
    description: "Programa de introducción al fitness",
    duration: "8 semanas",
    level: "Principiante",
    sessions: 24,
    assignedUsers: 15,
    exercises: ["Flexiones", "Sentadillas", "Plancha", "Caminata"],
  },
]

export default function TrainingPlanner() {
  const [showCreateForm, setShowCreateForm] = useState(false)
  const [newPlan, setNewPlan] = useState({
    name: "",
    description: "",
    duration: "",
    level: "",
    exercises: [],
  })

  const handleCreatePlan = () => {
    // Aquí implementarías la lógica para crear un nuevo plan
    console.log("Crear nuevo plan:", newPlan)
    setShowCreateForm(false)
    setNewPlan({ name: "", description: "", duration: "", level: "", exercises: [] })
  }

  const getLevelColor = (level: string) => {
    switch (level) {
      case "Principiante":
        return "bg-green-100 text-green-800"
      case "Intermedio":
        return "bg-yellow-100 text-yellow-800"
      case "Avanzado":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold text-gray-900 mb-2">Planificador de Entrenamientos</h2>
          <p className="text-gray-600">Crea y gestiona planes de entrenamiento personalizados</p>
        </div>
        <Button onClick={() => setShowCreateForm(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Nuevo Plan
        </Button>
      </div>

      {/* Create Plan Form */}
      {showCreateForm && (
        <Card>
          <CardHeader>
            <CardTitle>Crear Nuevo Plan de Entrenamiento</CardTitle>
            <CardDescription>Define los detalles del nuevo plan</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="planName">Nombre del Plan</Label>
                <Input
                  id="planName"
                  value={newPlan.name}
                  onChange={(e) => setNewPlan({ ...newPlan, name: e.target.value })}
                  placeholder="Ej: Plan de Fuerza Avanzado"
                />
              </div>
              <div>
                <Label htmlFor="duration">Duración</Label>
                <Select value={newPlan.duration} onValueChange={(value) => setNewPlan({ ...newPlan, duration: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Seleccionar duración" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="2 semanas">2 semanas</SelectItem>
                    <SelectItem value="4 semanas">4 semanas</SelectItem>
                    <SelectItem value="6 semanas">6 semanas</SelectItem>
                    <SelectItem value="8 semanas">8 semanas</SelectItem>
                    <SelectItem value="12 semanas">12 semanas</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label htmlFor="level">Nivel</Label>
              <Select value={newPlan.level} onValueChange={(value) => setNewPlan({ ...newPlan, level: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="Seleccionar nivel" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Principiante">Principiante</SelectItem>
                  <SelectItem value="Intermedio">Intermedio</SelectItem>
                  <SelectItem value="Avanzado">Avanzado</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="description">Descripción</Label>
              <Textarea
                id="description"
                value={newPlan.description}
                onChange={(e) => setNewPlan({ ...newPlan, description: e.target.value })}
                placeholder="Describe los objetivos y características del plan..."
                rows={3}
              />
            </div>
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setShowCreateForm(false)}>
                Cancelar
              </Button>
              <Button onClick={handleCreatePlan}>Crear Plan</Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Training Plans Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {trainingPlans.map((plan) => (
          <Card key={plan.id} className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex justify-between items-start">
                <CardTitle className="text-lg">{plan.name}</CardTitle>
                <Badge className={getLevelColor(plan.level)}>{plan.level}</Badge>
              </div>
              <CardDescription>{plan.description}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="flex items-center text-gray-600">
                    <Clock className="h-4 w-4 mr-2" />
                    <span>{plan.duration}</span>
                  </div>
                  <div className="flex items-center text-gray-600">
                    <Target className="h-4 w-4 mr-2" />
                    <span>{plan.sessions} sesiones</span>
                  </div>
                  <div className="flex items-center text-gray-600 col-span-2">
                    <Users className="h-4 w-4 mr-2" />
                    <span>{plan.assignedUsers} usuarios asignados</span>
                  </div>
                </div>

                <div>
                  <Label className="text-sm font-medium text-gray-700">Ejercicios principales:</Label>
                  <div className="flex flex-wrap gap-1 mt-2">
                    {plan.exercises.slice(0, 3).map((exercise, index) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        {exercise}
                      </Badge>
                    ))}
                    {plan.exercises.length > 3 && (
                      <Badge variant="outline" className="text-xs">
                        +{plan.exercises.length - 3} más
                      </Badge>
                    )}
                  </div>
                </div>

                <div className="flex space-x-2 pt-4">
                  <Button variant="outline" size="sm" className="flex-1 bg-transparent">
                    <Edit className="h-4 w-4 mr-1" />
                    Editar
                  </Button>
                  <Button variant="outline" size="sm" className="flex-1 bg-transparent">
                    <Calendar className="h-4 w-4 mr-1" />
                    Asignar
                  </Button>
                  <Button variant="outline" size="sm">
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Weekly Schedule Preview */}
      <Card>
        <CardHeader>
          <CardTitle>Vista Semanal</CardTitle>
          <CardDescription>Planificación de entrenamientos por semana</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-7 gap-2">
            {["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"].map((day, index) => (
              <div key={day} className="text-center">
                <div className="font-semibold text-sm text-gray-700 mb-2">{day}</div>
                <div className="space-y-1">
                  {index < 5 && <div className="bg-blue-100 text-blue-800 text-xs p-2 rounded">Fuerza</div>}
                  {index === 2 && <div className="bg-green-100 text-green-800 text-xs p-2 rounded">Cardio</div>}
                  {index === 6 && <div className="bg-gray-100 text-gray-600 text-xs p-2 rounded">Descanso</div>}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

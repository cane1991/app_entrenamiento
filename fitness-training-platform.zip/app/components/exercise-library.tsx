"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Play, Search, Filter, Clock, Target } from "lucide-react"

const exercises = [
  {
    id: 1,
    name: "Sentadillas",
    category: "Piernas",
    difficulty: "Intermedio",
    duration: "3-4 series x 12-15 reps",
    muscleGroups: ["Cuádriceps", "Glúteos"],
    videoUrl: "/placeholder.svg?height=200&width=300",
    description: "Ejercicio fundamental para fortalecer piernas y glúteos",
  },
  {
    id: 2,
    name: "Flexiones de Pecho",
    category: "Pecho",
    difficulty: "Principiante",
    duration: "3 series x 8-12 reps",
    muscleGroups: ["Pectorales", "Tríceps", "Deltoides"],
    videoUrl: "/placeholder.svg?height=200&width=300",
    description: "Ejercicio clásico para desarrollar fuerza en el tren superior",
  },
  {
    id: 3,
    name: "Peso Muerto",
    category: "Espalda",
    difficulty: "Avanzado",
    duration: "4 series x 6-8 reps",
    muscleGroups: ["Espalda Baja", "Glúteos", "Isquiotibiales"],
    videoUrl: "/placeholder.svg?height=200&width=300",
    description: "Ejercicio compuesto para fortalecer toda la cadena posterior",
  },
  {
    id: 4,
    name: "Plancha",
    category: "Core",
    difficulty: "Intermedio",
    duration: "3 series x 30-60 seg",
    muscleGroups: ["Abdominales", "Core"],
    videoUrl: "/placeholder.svg?height=200&width=300",
    description: "Ejercicio isométrico para fortalecer el core",
  },
  {
    id: 5,
    name: "Burpees",
    category: "Cardio",
    difficulty: "Avanzado",
    duration: "3 series x 10-15 reps",
    muscleGroups: ["Cuerpo Completo"],
    videoUrl: "/placeholder.svg?height=200&width=300",
    description: "Ejercicio de alta intensidad para cardio y fuerza",
  },
  {
    id: 6,
    name: "Dominadas",
    category: "Espalda",
    difficulty: "Avanzado",
    duration: "3 series x 5-10 reps",
    muscleGroups: ["Dorsales", "Bíceps"],
    videoUrl: "/placeholder.svg?height=200&width=300",
    description: "Ejercicio para desarrollar fuerza en la espalda y brazos",
  },
]

export default function ExerciseLibrary() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [selectedDifficulty, setSelectedDifficulty] = useState("all")

  const categories = ["all", "Piernas", "Pecho", "Espalda", "Core", "Cardio"]
  const difficulties = ["all", "Principiante", "Intermedio", "Avanzado"]

  const filteredExercises = exercises.filter((exercise) => {
    const matchesSearch =
      exercise.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      exercise.description.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = selectedCategory === "all" || exercise.category === selectedCategory
    const matchesDifficulty = selectedDifficulty === "all" || exercise.difficulty === selectedDifficulty

    return matchesSearch && matchesCategory && matchesDifficulty
  })

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Principiante":
        return "bg-green-100 text-green-800"
      case "Intermedio":
        return "bg-yellow-100 text-yellow-800"
      case "Avanzado":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold text-gray-900 mb-2">Biblioteca de Ejercicios</h2>
        <p className="text-gray-600">Explora nuestra colección de ejercicios con videos explicativos</p>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Buscar ejercicios..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Categoría" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((category) => (
                  <SelectItem key={category} value={category}>
                    {category === "all" ? "Todas las categorías" : category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={selectedDifficulty} onValueChange={setSelectedDifficulty}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Dificultad" />
              </SelectTrigger>
              <SelectContent>
                {difficulties.map((difficulty) => (
                  <SelectItem key={difficulty} value={difficulty}>
                    {difficulty === "all" ? "Todas las dificultades" : difficulty}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Exercise Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredExercises.map((exercise) => (
          <Card key={exercise.id} className="overflow-hidden hover:shadow-lg transition-shadow">
            <div className="relative">
              <img
                src={exercise.videoUrl || "/placeholder.svg"}
                alt={exercise.name}
                className="w-full h-48 object-cover"
              />
              <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                <Button size="lg" className="bg-white text-black hover:bg-gray-100">
                  <Play className="h-5 w-5 mr-2" />
                  Ver Video
                </Button>
              </div>
            </div>
            <CardHeader>
              <div className="flex justify-between items-start">
                <CardTitle className="text-lg">{exercise.name}</CardTitle>
                <Badge className={getDifficultyColor(exercise.difficulty)}>{exercise.difficulty}</Badge>
              </div>
              <CardDescription>{exercise.description}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center text-sm text-gray-600">
                  <Target className="h-4 w-4 mr-2" />
                  <span>{exercise.category}</span>
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <Clock className="h-4 w-4 mr-2" />
                  <span>{exercise.duration}</span>
                </div>
                <div className="flex flex-wrap gap-1">
                  {exercise.muscleGroups.map((muscle, index) => (
                    <Badge key={index} variant="outline" className="text-xs">
                      {muscle}
                    </Badge>
                  ))}
                </div>
                <Button className="w-full mt-4">Agregar a Rutina</Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredExercises.length === 0 && (
        <Card>
          <CardContent className="p-12 text-center">
            <Filter className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No se encontraron ejercicios</h3>
            <p className="text-gray-600">Intenta ajustar los filtros de búsqueda</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

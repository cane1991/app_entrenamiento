-- Crear tablas en Supabase
CREATE TABLE users (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  email VARCHAR UNIQUE NOT NULL,
  name VARCHAR NOT NULL,
  password_hash VARCHAR NOT NULL,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE exercises (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name VARCHAR NOT NULL,
  description TEXT,
  video_url VARCHAR,
  muscle_groups TEXT[],
  difficulty VARCHAR CHECK (difficulty IN ('Principiante', 'Intermedio', 'Avanzado')),
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE user_routines (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES users(id),
  name VARCHAR NOT NULL,
  description TEXT,
  trainer VARCHAR,
  current_week INTEGER DEFAULT 1,
  total_weeks INTEGER,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE routine_exercises (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  routine_id UUID REFERENCES user_routines(id),
  exercise_id UUID REFERENCES exercises(id),
  sets VARCHAR,
  weight VARCHAR,
  rest_time VARCHAR,
  order_index INTEGER
);

CREATE TABLE user_progress (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES users(id),
  exercise_id UUID REFERENCES exercises(id),
  completed_at TIMESTAMP DEFAULT NOW(),
  notes TEXT
);
